﻿namespace GenshinDailyTools.Exception
{
    public class GenShinException : System.Exception
    {
        public GenShinException(string message) : base(message)
        {

        }
    }
}
